Orden sugerido de implementación para la resolución de la práctica (y consiguiente ejecución de los tests correspondientes).

Level 1: Color, Coordenada, Sentido y TipoPieza
Level 2: Celda, Jugada y Pieza 
Level 3: Tablero
Level 4: Caja y TableroConsultor
Level 5: Arbitro (tests básicos)
Level 6: Arbitro (tests básicos y medios)
Level 7: Arbitro (tests básicos, medios y avanzados)
Level 8: Jerarquía de herencia en subpaquete undo
Level 9: Excepción comprobable

Para ejecutar los tests de cada nivel ("Level") se proporcionan "suites" correspondientes (e.g. SuiteLevel1Test).

En el caso del Arbitro se descomponen los tests en distintos niveles, de menor a mayor dificultad.